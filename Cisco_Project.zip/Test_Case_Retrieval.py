#!C:\Users\abrad\AppData\Local\Programs\Python\Python36-32\python.exe
# !/usr/bin/env python3

from __future__ import print_function
import sys
import os
from os import path
import re
import json
from robot.parsing.model import TestData


print('Content-type: application/json')
print()


def parse_data(robotfile):
    suite = TestData(parent=None, source=robotfile)
    testcases = suite.testcase_table.tests
    for t in testcases:
        if tags:
            data.append({'Test Case Name: ': t.name})
    json.dumps(data)


def main():
    rootdir = sys.argv[1]
    for (filenames) in os.walk(rootdir):
        assert isinstance(filenames, object)
    for f in filenames:
        if re.search('.robot$', f):
            parse_data(path.join(dirpath, f))


if __name__ == "__main__":
    main()
