$(window).on('load', function(){
  $.ajax({
    type:'GET',
    url:"http://localhost/Cisco_Project/Test_Case_Retrieval.py",
    contentType:'application/json; charset=iso-8859-1',
    dataType:'json',
    success: function(data){

      var caseNames = "";
      for(var tests in data){
        caseNames += data["Test Case Name"] + "\n";
      }

      window.alert(caseNames);
    },
    error: function(request, status, error){
      window.alert(error);
    }
  })
});
